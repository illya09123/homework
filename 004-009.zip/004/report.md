Codex demonstration: the first commit captures both original files.
The date correction can be inspected separately.
The train and budget entries share a commit because they describe one purchase.
Only named files were staged, so scratch.txt never entered history.
