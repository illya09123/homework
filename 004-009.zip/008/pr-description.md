# Late cancellation fee
## Що змінено
Added rule 5 and its changelog entry.
## Як перевірити
Read rule 5 and compare the fee and deadline with the latest requirement.
## Ризики
A percentage change affects the amount refunded to customers.
