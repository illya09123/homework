Codex demo, prediction before merging:
typo-fix, refunds, discounts: each diverged from main at 6309fbc, so each merge is three-way.
refunds and discounts edit rule 2, so their changes will overlap.
All three merges were three-way. Only the discounts merge conflicted.
Requirement distinguishes groups of several people from the five-person discount threshold.
*   1c65a61 Reconcile owner and group cancellation policies
|\  
| * 3e85f60 Додати правила для груп
* |   9d92920 Merge branch 'refunds'
|\ \  
| * | 75139ad Додати правило повернення коштів
| |/  
* |   7247adb Merge branch 'typo-fix'
|\ \  
| * | 9c6cee0 Виправити друкарську помилку в README
| |/  
* | 4c6e7e8 Predict the three branch merges
* | cae2609 Додати вимогу замовника до правила 2
|/  
* 6309fbc Початкові правила
