Codex local demonstration.
Regression 45264c7c07e2a724a45b2a24d47d2c905506e755 shortened the cancellation deadline from 24 hours to 2.
git log -p -- rules/cancellation.md identifies the change, git revert reverses it.
Merged group discount and retained online payment and student eligibility.
git check-ignore -v verified all three patterns, git ls-files verified .env.example.
*   bf2c610 Reconcile student eligibility with online payment
|\  
| * 05b821d Оновити студентську знижку й додати нову
* | 0390f04 Revert "Уточнити формулювання правила скасування"
* |   1bd0347 Merge branch 'feature/ignore-local'
|\ \  
| * | c13b84d Ignore local credentials and generated files
|/ /  
* | 4ce878b Додати правило листа очікування
* | 11945f9 Обмежити студентську знижку онлайн-оплатою
* | 45264c7 Уточнити формулювання правила скасування
|/  
* 0e5bbfd Додати контакт команди в README
* 2a7ac4d Додати початкові правила й опис
