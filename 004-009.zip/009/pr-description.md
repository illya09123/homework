# Ignore local files
## Що змінено
Ignore .env, logs/ and temporary files.
## Як перевірити
Run git check-ignore -v against each local path.
## Ризики
A previously committed secret would require separate remediation.
## Самоперевірка перед запитом рев'ю
git ls-files --error-unmatch .env.example confirms the safe example remains tracked.
