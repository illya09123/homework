643969b Тарас Бондар Thu Mar 5 17:30:00 2026 +0200
Codex demo: git log -p -- capacity.md shows 20 became 2.
git revert preserves the published commits while reversing the regression.
30 + 20 + 15 + 12 = 77. README now agrees.
git restore recovered venues.md from the parent of its deletion.
